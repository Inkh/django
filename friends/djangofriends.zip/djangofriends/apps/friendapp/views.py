from django.shortcuts import render
from . import models
# Create your views here.
def index(req):
    # users = models.Users.objects.all()
    # users = models.Users.objects.exclude(last_name="Rodriguez")
    # users = models.Users.objects.filter(last_name="Rodriguez") | models.Users.objects.filter(first_name="Daniel")
    # users = models.Users.objects.filter(last_name="Rodriguez").exclude(first_name="Madison")
    # users = models.Users.objects.all().order_by('first_name')
    # users = models.Users.objects.all().order_by('-last_name')
    # users = models.Users.objects.all().exclude(first_name="Daniel").exclude(first_name="Michael")
    # users = models.Users.objects.get(id=10000)
    # jim = models.Friendships.objects.filter(user_id = 4)
    # users = models.Friendships.objects.filter(friend_id = 4)
    # users = models.Friendships.objects.exclude(friend_id = 5).exclude(friend_id = 4).exclude(friend_id = 6)
    users = models.Friendships.objects.exclude(user__in=[4, 5, 6])
    # friends = models.Friendships.objects.filter(user_id = 4)
    # print friends
    # users = models.Friendships.objects.get(id=6)
    # friendships = models.Friendships.objects.all()
    # print users.query
    # print users
    # print users.last_name
    context = {'users':users}
    return render(req, "friendapp/index.html",context)
